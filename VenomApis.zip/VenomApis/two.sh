
GREEN='\033[0;32m'
clear
while :
do
echo "${GREEN} iníciando venom rest apis...."

npm start
sleep 1      
done
