/*
Venom na voz, essa base de site foi feito totalmente por mim
base totalmente grátis para aprender fazer seu próprio site de apis
qualquer venda nessa source entre em contato comigo pelo WhatsApp ou telegram

Se for postar ou usar deixe apenas os créditos 

youtube.com/@venommodsss
youtube.com/@venomkuromi
wa.me/559784388524
*/